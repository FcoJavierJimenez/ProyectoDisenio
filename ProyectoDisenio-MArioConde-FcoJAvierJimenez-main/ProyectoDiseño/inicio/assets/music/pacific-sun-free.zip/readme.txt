Thank you so much for your download!

Music composed by Nicolai Heidlas exclusively for HookSounds.com.

Your support means the world to us and we hope that you are happy with your download. If there's anything that we can do to make you even happier, please let us know!

=========================================================================================================

This music is issued under the HookSounds USE &amp; MENTION license. This means that YOU MUST GIVE ATTRIBUTION to HookSounds for this musical composition in the designated project description section. Please refer to https://www.hooksounds.com/faq/#2 on how to give proper attribution.

Also note that this USE &amp; MENTION license is only valid for PERSONAL USE. You may NOT MONETIZE your content or receive any other commercial benefits for your projects with this license. Commercial projects (monetized content, advertisements, music played in public installments, etc.) require the appropriate paid license(s) (PRO, BUSINESS or BROADCAST).

Please refer to https://www.hooksounds.com/licensing/ to learn more about our licenses or contact our customer support via e-mail: support@hooksounds.com.

If you want to use this music file WITHOUT giving attribution, you MUST purchase a paid license at http:/www.hooksounds.com.

Visit hooksounds.com for more quality music.

Hope you enjoy our music!
http://www.hooksounds.com